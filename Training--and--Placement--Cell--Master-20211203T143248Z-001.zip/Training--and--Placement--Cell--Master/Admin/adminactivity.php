<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="navigation.css">
	</style>
</head>
<body>
<div class="topnav"><a class="active" href="showstudent.php">View Students</a><a href="announcement.php">Announcement</a><a  href="update_college_info.php">Update College Info</a><a  href="addcompany.php">Add Company</a><a  href="../HomePage/home.php">Log out</a></div>
</body>
</html>