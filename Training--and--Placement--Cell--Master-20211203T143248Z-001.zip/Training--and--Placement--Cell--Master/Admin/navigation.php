<!DOCTYPE html>
<html>
<head>
	</head>
	<link rel="stylesheet" type="text/css" href="navigation.css">
</head>
<body>
<div class="topnav"><a href="https://www.snjb/Polytechnic/.org">Shri H.H.J.B.Polytechnic</a><center><a class="active" href="#home">Home</a><a href="studentregistration.php">Student Registration</a><a  href="adminlogin.php">admin Login</a><a  href="studentlogin.html">Student Login</a><a  href="recruiterlogin.html">Recruiter Login</a></center></div>
</body>
</html>