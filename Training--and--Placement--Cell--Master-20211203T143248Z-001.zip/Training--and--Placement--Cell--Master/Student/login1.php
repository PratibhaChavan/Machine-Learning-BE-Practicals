<?php
$hn='localhost';
$db='login';
$un='root';
$pw='';
?>