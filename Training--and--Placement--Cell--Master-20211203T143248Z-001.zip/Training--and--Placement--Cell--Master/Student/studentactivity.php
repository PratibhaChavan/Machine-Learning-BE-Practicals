<!DOCTYPE html>
<html>
<head>
	<title>Student Activity</title>
<link rel="stylesheet" type="text/css" href="navigation.css">
	</style>
</head>
<body>
<div class="topnav"><a class="active" href="showstudent.php">View Students</a><a href="showaanouncement.php"> View Announcement</a><a  href="viewcompany.php">View Company</a><a  href="../HomePage/home.php">Log out</a></div>
</body>
</html>