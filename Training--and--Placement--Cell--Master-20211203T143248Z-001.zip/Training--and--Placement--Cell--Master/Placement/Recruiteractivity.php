<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="navigation.css">
</head>
<body>
<div class="topnav"><a class="active" href="showstudent.php">Select Students</a><a href="viewcollege.php">View College</a><a  href="../Homepage/home.php">Log out</a></div>
</body>
</html>